READ-ME FILE

"Functions.R": FUNCTIONS TO IMPLEMENT THE SPARSE COINTEGRATION METHOD AS DESCRIBED IN  Wilms I. and Croux C. (2016), "Forecasting using sparse cointegration"
"Benchmarks.R": BENCHMARKS USED IN CONSUMPTION FORECAST SECTION OF PAPER Wilms I. and Croux C. (2016), "Forecasting using sparse cointegration."
"TestSparseCointegration.R": R-SCRIPT TEST CODE SPARSE COINTEGRATION
"EstimationAccuracy.R": R-SCRIPT SIMULATION STUDY: ESTIMATION ACCURACY LOW-DIMENSIONAL SPARSE DESIGN q=4, T=500, r=1 OF PAPER Wilms I. and Croux C. (2016), "Forecasting using sparse cointegration."
"ForecastAccuracy.R": R-SCRIPT SIMULATION STUDY: FORECAST ACCURACY LOW-DIMENSIONAL SPARSE DESIGN q=4, T=500, r=1 OF PAPER Wilms I. and Croux C. (2016), "Forecasting using sparse cointegration."
"RankDetermination": R-SCRIPT SIMULATION STUDY RANK DETERMINATION: LOW-DIMENSIONAL SPARSE DESIGN q=4, T=500, r=1 OF PAPER Wilms I. and Croux C. (2016), "Forecasting using sparse cointegration."